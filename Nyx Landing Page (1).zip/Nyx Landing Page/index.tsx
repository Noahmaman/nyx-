import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, Globe, Leaf, Users, Zap, Home, Map, Shield } from 'lucide-react'

export default function NyxLandingPage() {
  const [activeTab, setActiveTab] = useState("explore")

  return (
    <div className="min-h-screen bg-gradient-to-b from-black to-gray-900 text-white">
      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20 text-center">
        <h1 className="mb-6 text-5xl font-bold leading-tight">
          Welcome to Nyx: The Future of Accommodation Booking
        </h1>
        <p className="mb-8 text-xl">
          Experience sustainable, immersive, and personalized travel like never before
        </p>
        <Button size="lg" className="bg-purple-600 hover:bg-purple-700">
          Get Started <ArrowRight className="ml-2" />
        </Button>
      </section>

      {/* Key Features Section */}
      <section className="bg-gray-800 py-20">
        <div className="container mx-auto px-4">
          <h2 className="mb-12 text-center text-4xl font-bold">Key Features</h2>
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            <FeatureCard
              icon={<Globe className="h-10 w-10 text-purple-500" />}
              title="Intelligent Property Matching"
              description="AI-powered recommendations based on your preferences and travel patterns"
            />
            <FeatureCard
              icon={<Leaf className="h-10 w-10 text-green-500" />}
              title="Sustainable Living Experiences"
              description="Eco-friendly accommodations and carbon-neutral options"
            />
            <FeatureCard
              icon={<Zap className="h-10 w-10 text-yellow-500" />}
              title="Seamless Booking & Management"
              description="Streamlined process with voice commands and biometric authentication"
            />
            <FeatureCard
              icon={<Map className="h-10 w-10 text-blue-500" />}
              title="Immersive Exploration"
              description="Virtual tours and mixed reality experiences of properties and local attractions"
            />
            <FeatureCard
              icon={<Home className="h-10 w-10 text-red-500" />}
              title="Comprehensive Host Tools"
              description="Automated property management and sustainable hosting certifications"
            />
            <FeatureCard
              icon={<Users className="h-10 w-10 text-indigo-500" />}
              title="Community-Driven Ecosystem"
              description="Decentralized governance and social impact initiatives"
            />
          </div>
        </div>
      </section>

      {/* Sustainability Section */}
      <section className="container mx-auto px-4 py-20">
        <h2 className="mb-8 text-center text-4xl font-bold">Committed to Sustainability</h2>
        <div className="flex flex-wrap items-center justify-center gap-8">
          <Card className="w-full max-w-md bg-green-900">
            <CardHeader>
              <CardTitle>Eco-Friendly Accommodations</CardTitle>
            </CardHeader>
            <CardContent>
              <p>
                Discover and book properties that prioritize renewable energy, minimal environmental
                impact, and sustainable practices.
              </p>
            </CardContent>
          </Card>
          <Card className="w-full max-w-md bg-green-900">
            <CardHeader>
              <CardTitle>Carbon Footprint Tracking</CardTitle>
            </CardHeader>
            <CardContent>
              <p>
                Monitor and offset your travel's environmental impact with our integrated carbon
                footprint calculator and offsetting marketplace.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Immersive Exploration Showcase */}
      <section className="bg-gray-800 py-20">
        <div className="container mx-auto px-4">
          <h2 className="mb-8 text-center text-4xl font-bold">Immersive Exploration</h2>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="explore">Virtual Tours</TabsTrigger>
              <TabsTrigger value="ar">Augmented Reality</TabsTrigger>
            </TabsList>
            <TabsContent value="explore" className="mt-4">
              <div className="aspect-video w-full rounded-lg bg-gray-700">
                {/* Placeholder for Virtual Tour Demo */}
                <div className="flex h-full items-center justify-center">
                  <p className="text-xl">Interactive Virtual Tour Demo</p>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="ar" className="mt-4">
              <div className="aspect-video w-full rounded-lg bg-gray-700">
                {/* Placeholder for AR Demo */}
                <div className="flex h-full items-center justify-center">
                  <p className="text-xl">Augmented Reality Experience Demo</p>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Community-Driven Ecosystem */}
      <section className="container mx-auto px-4 py-20">
        <h2 className="mb-8 text-center text-4xl font-bold">Join Our Community</h2>
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          <Card className="bg-indigo-900">
            <CardHeader>
              <CardTitle>Decentralized Governance</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Have a say in the platform's future through community voting and proposals.</p>
            </CardContent>
          </Card>
          <Card className="bg-indigo-900">
            <CardHeader>
              <CardTitle>Peer-to-Peer Sharing</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Share resources and experiences with fellow travelers and hosts.</p>
            </CardContent>
          </Card>
          <Card className="bg-indigo-900">
            <CardHeader>
              <CardTitle>Social Impact Initiatives</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Participate in projects that give back to local communities and the environment.</p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Call-to-Action Section */}
      <section className="bg-purple-900 py-20">
        <div className="container mx-auto px-4 text-center">
          <h2 className="mb-6 text-4xl font-bold">Ready to Reimagine Travel?</h2>
          <p className="mb-8 text-xl">
            Join Nyx today and experience the future of accommodation booking.
          </p>
          <Button size="lg" className="bg-white text-purple-900 hover:bg-gray-200">
            Sign Up Now <ArrowRight className="ml-2" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 py-8">
        <div className="container mx-auto px-4 text-center">
          <p>&copy; 2024 Nyx. All rights reserved.</p>
          <div className="mt-4 flex justify-center space-x-4">
            <Badge variant="outline">Privacy Policy</Badge>
            <Badge variant="outline">Terms of Service</Badge>
            <Badge variant="outline">Contact Us</Badge>
          </div>
        </div>
      </footer>
    </div>
  )
}

function FeatureCard({ icon, title, description }) {
  return (
    <Card className="bg-gray-700">
      <CardHeader>
        <div className="mb-2">{icon}</div>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <CardDescription>{description}</CardDescription>
      </CardContent>
    </Card>
  )
}